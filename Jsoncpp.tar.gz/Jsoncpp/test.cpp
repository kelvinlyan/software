#include "json/json.h"
#include <iostream>

int main()
{
	Json::Value msg;
	msg["a"] = 1;
	std::cout << msg.toStyledString() << std::endl;
}
