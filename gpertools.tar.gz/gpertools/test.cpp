#include <google/profiler.h>

int main()
{
    ProfilerStart("test.log");
    ProfilerStop();
}
